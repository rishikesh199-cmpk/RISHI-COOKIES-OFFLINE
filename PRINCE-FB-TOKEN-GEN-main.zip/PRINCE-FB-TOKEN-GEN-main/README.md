# Facebook-Access-Token

Generating a full permission (Android | iPhone) Facebook Access Token

## How to use

```
git clone https://github.com/locmai0808/Facebook-Access-Token.git
cd Facebook-Access-Token
npm install
npm start
```

Open a browser and go to `http://localhost:5000/`
